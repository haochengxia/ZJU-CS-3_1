#include<linux/module.h>
#include <linux/sched/cputime.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>

/*#define container_of(ptr, type, member) ({          \  
       const typeof( ((type *)0)->member ) *__mptr = (ptr); \  
       (type *)( (char *)__mptr - offsetof(type,member) );}) */

static void thread_print(struct task_struct *tsk);
static void process_print(struct task_struct *tsk);


static int YOUR_INIT(void){
//添加实现代码，输出所有进程及所属线程信息
	struct task_struct *tsk;
    process_print(tsk);
    return 0;

}
static void YOUR_EXIT(void){
    printk(KERN_ALERT " exit\n");
}
module_init(YOUR_INIT);
module_exit(YOUR_EXIT);
MODULE_LICENSE("GPL");

/** function: process_print()
 * print process details
 */
static void process_print(struct task_struct *tsk){
    for_each_process(tsk)
	{
		printk(KERN_ALERT"proc   details :pid:%d\t tgid:%d\t stack:%x\t task_struct:%x\t mm_struct:%x\t name:%s\n", tsk->pid,  tsk->tgid, tsk->stack, tsk, tsk->mm, tsk->comm);
        thread_print(tsk);
	}
}

/** function: thread_print()
 * print thread details
 */
static void thread_print(struct task_struct *tsk){
    unsigned long offset;
    struct task_struct *current_thread=NULL;
    struct list_head *current_list = NULL;
     struct list_head *real_head  = NULL;
    offset=offsetof(struct task_struct,thread_group);
    current_thread = tsk;
    real_head = &(current_thread->thread_group);
    current_list = &(current_thread->thread_group);
    //添加实现代码，遍历线程并输出
    while(1){
        if(current_list!=NULL) {
            current_thread = container_of(current_list,struct task_struct,thread_group);
            printk(KERN_ALERT"thread details :pid:%d\t tgid:%d\t stack:%x\t task_struct:%x\t mm_struct:%x\t name:%s\n", current_thread->pid,current_thread->tgid, current_thread->stack, current_thread, current_thread->mm, current_thread->comm);
            current_list = current_list->next;
            if (current_list == real_head)  return;    
        }
        else{
            return;
        }
    }
}