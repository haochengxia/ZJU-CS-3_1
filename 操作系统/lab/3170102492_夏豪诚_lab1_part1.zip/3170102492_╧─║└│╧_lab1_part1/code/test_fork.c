/** file: test_fork.c
 *  for Part1 Question4
 */
include <unistd.h>
int main(){
    pid_t p1, p2;
    p1 = fork();
    if (p1 == 0){
        while(1){;}
    }
    else {
        p2 = fork();
        if (p2 == 0){
            while (1){;}
        }
        else {
            while (1){;}
        }
    }
}
~  