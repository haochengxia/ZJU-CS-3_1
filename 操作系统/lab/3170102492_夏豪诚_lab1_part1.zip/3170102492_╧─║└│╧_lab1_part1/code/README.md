# 已修改代码列表

### 自行编写：



your_module.c

* 说明：‘b.c’为Part1中的模块文件代码

Makefile

* 说明：‘Makefile’为Part1中模块程序所在目录下的Makefile文件

test_fork.c

* 说明：Part1问题4中为了探讨线程和子进程的区别，编写的程序，功能为在父进程下fork出两个子进程，并均进入死循环

