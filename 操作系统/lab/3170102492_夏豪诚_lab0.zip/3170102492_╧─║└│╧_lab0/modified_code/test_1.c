#include<stdio.h>
#include<unistd.h>
#include<sys/syscall.h>
#define __NR_mysyscall 335

int main(){
	unsigned long pfcount;
	pfcount = syscall(__NR_mysyscall);
	printf("the whole system page fault: %ld\n",pfcount);
	while(1);
	return 0;
}
