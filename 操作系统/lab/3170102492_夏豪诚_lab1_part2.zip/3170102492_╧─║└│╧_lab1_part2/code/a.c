/** file: a.c
* Lab1 Part2 test_program 1
*/
#define __LIBRARY__
#define __NR_setpriority 74
#include <unistd.h>
_syscall2(int, setpriority, int, pid, unsigned short, prio)
int main(){
    pid_t p1, p2;
    setpriority(getpid(),3);
    p1 = fork();
    if (p1 == 0){
        while(1){;}
    }
    else {
        setpriority(p1,1);
        p2 = fork();
        if (p2 == 0){
            while (1){;}  
        }
        else {
            setpriority(p2,2);
            while (1){;}  
        }
    }
}